; DGREV -- Add the supplied revision-only DWG to the original drawing.
; AutoCAD / AutoCAD Mechanical 2010 or later; Visual LISP / ActiveX required.
; This file is ASCII for older AutoCAD compatibility.
; No SAVE, SAVEAS, EXPLODE, PURGE or edits to existing entities are performed.
; InsertBlock takes WCS coordinates; the current UCS is never changed.

(vl-load-com)

(defun dgrev:restore-vars (items / item)
  (foreach item items
    (vl-catch-all-apply 'setvar (list (car item) (cdr item)))
  )
)

(defun dgrev:delete-object (obj)
  (if obj (vl-catch-all-apply 'vla-Delete (list obj)))
)

(defun dgrev:revision-source-p (block / count item valid frame note layer)
  (setq count (vla-get-Count block))
  ; The delivered sheet has 483 simple entities on DGREV_ layers.
  ; The upper limit rejects an accidentally selected complete source drawing.
  (setq valid (and (> count 0) (<= count 1000)))
  (if valid
    (vlax-for item block
      (setq layer (strcase (vla-get-Layer item)))
      (if (not (wcmatch layer "DGREV_*")) (setq valid nil))
      (if (= layer "DGREV_FRAME") (setq frame T))
      (if (= layer "DGREV_NOTE") (setq note T))))
  (and valid frame note)
)

(defun dgrev:add-sheet (doc filename / ms blocks blockname layer vp lo hi dx dy pad)
  ; The variables beginning with dg- are local to c:DGREV and dynamically scoped.
  (vla-StartUndoMark doc)
  (setq dg-undo T)
  (setq ms (vla-get-ModelSpace doc))
  ; A temporary empty block ensures that the undo group contains a DB change,
  ; even if the later insertion fails before returning a block reference.
  (setq blocks (vla-get-Blocks doc))
  (setq dg-sentinel
    (vla-Add blocks (vlax-3d-point '(0.0 0.0 0.0))
      (strcat (vl-filename-base filename) "_UNDO_MARKER")))
  (setq dg-changed T)
  ; The supplied revision sheet is authored in millimetres. All three values
  ; are restored before this undo group is closed.
  (setvar "INSUNITS" 4)
  (setvar "INSUNITSDEFSOURCE" 4)
  (setvar "INSUNITSDEFTARGET" 4)
  (setq dg-insert
    (vla-InsertBlock ms (vlax-3d-point '(0.0 0.0 0.0))
      filename 1.0 1.0 1.0 0.0))
  (setq blockname (vla-get-Name dg-insert))
  (if (not (dgrev:revision-source-p (vla-Item blocks blockname)))
    (setq dg-problem "Select the supplied revision-only DWG. This file is not that sheet.")
    (progn
  (vla-put-Name (vla-Item blocks blockname) dg-marker)
  (if (not (tblsearch "LAYER" "DGREV_SHEET"))
    (vla-Add (vla-get-Layers doc) "DGREV_SHEET"))
  (vla-put-Layer dg-insert "DGREV_SHEET")
  ; Show the new model-space sheet. COM insertion and view properties use WCS.
  ; This changes the view only, without changing UCS or existing geometry.
  (setvar "TILEMODE" 1)
  (setq vp (vla-get-ActiveViewport doc))
  (vla-put-Direction vp (vlax-3d-point '(0.0 0.0 1.0)))
  (vla-put-Target vp (vlax-3d-point '(0.0 0.0 0.0)))
  (if (vlax-property-available-p vp 'TwistAngle T)
    (vla-put-TwistAngle vp 0.0))
  (vla-put-ActiveViewport doc vp)
  (vla-GetBoundingBox dg-insert 'lo 'hi)
  (setq lo (vlax-safearray->list lo))
  (setq hi (vlax-safearray->list hi))
  (setq dx (- (car hi) (car lo)))
  (setq dy (- (cadr hi) (cadr lo)))
  (if (or (<= dx 0.0) (<= dy 0.0))
    (setq dg-problem "The selected DWG does not contain a valid two-dimensional sheet.")
    (progn
      (setq pad (* 0.025 (max dx dy)))
      (vla-ZoomWindow (vlax-get-acad-object)
        (vlax-3d-point (list (- (car lo) pad) (- (cadr lo) pad) 0.0))
        (vlax-3d-point (list (+ (car hi) pad) (+ (cadr hi) pad) 0.0)))
      (vla-Delete dg-sentinel)
      (setq dg-sentinel nil)))
    ))
  T
)

(defun c:DGREV (/ doc selected temporary settings result ended rolled
                  dg-marker dg-undo dg-changed dg-insert dg-sentinel dg-problem)
  (setq dg-marker "DGREV_260438_DS0218_REV1")
  (setq doc (vla-get-ActiveDocument (vlax-get-acad-object)))
  (cond
    ((tblsearch "BLOCK" dg-marker)
      (prompt "\nRevision marker already exists. No changes made."))
    ((= 0 (logand 1 (getvar "UNDOCTL")))
      (prompt "\nUNDO is disabled. Enable UNDO, then run DGREV again."))
    ((/= 0 (logand 8 (getvar "UNDOCTL")))
      (prompt "\nAn UNDO group is active. Finish it, then run DGREV again."))
    ((not (setq selected
       (getfiled "Select the supplied REVISION-ONLY DWG (not the original)"
         "" "dwg" 0)))
      (prompt "\nCancelled. No changes made."))
    ((not (findfile selected))
      (prompt "\nThe selected file is not accessible. No changes made."))
    (T
      ; A unique temporary filename avoids redefinition of any pre-existing
      ; block whose name happens to match the user's selected filename.
      (setq temporary (vl-filename-mktemp "DGREV_IMPORT_" (getvar "TEMPPREFIX") ".dwg"))
      (if (not (vl-file-copy selected temporary))
        (prompt "\nCannot copy the source to the temporary folder. No changes made.")
        (progn
          (setq settings
            (list (cons "INSUNITS" (getvar "INSUNITS"))
                  (cons "INSUNITSDEFSOURCE" (getvar "INSUNITSDEFSOURCE"))
                  (cons "INSUNITSDEFTARGET" (getvar "INSUNITSDEFTARGET"))))
          ; All mutations are protected by catch-all; cancellation/errors
          ; return here so UNDO can run in normal command context on 2010+.
          (setq result (vl-catch-all-apply 'dgrev:add-sheet (list doc temporary)))
          (dgrev:restore-vars settings)
          (if dg-undo
            (progn
              (setq ended (vl-catch-all-apply 'vla-EndUndoMark (list doc)))
              (if (vl-catch-all-error-p ended) (setq result ended))))
          (if (or (vl-catch-all-error-p result) dg-problem)
            (progn
              (if dg-changed
                (setq rolled (vl-catch-all-apply 'vl-cmdf (list "_.UNDO" 1))))
              (if (and dg-changed (vl-catch-all-error-p rolled))
                (progn
                  (dgrev:delete-object dg-insert)
                  (dgrev:delete-object dg-sentinel)
                  (prompt "\nUNDO failed. Do not save; inspect the drawing or reopen the original."))
                (prompt "\nRevision insertion failed; its changes were rolled back."))
              (prompt (strcat "\nReason: "
                (if dg-problem dg-problem (vl-catch-all-error-message result)))))
            (progn
              (vl-catch-all-apply 'vla-Regen (list doc 1))
              (prompt "\nRevision sheet added at WCS (0,0,0), scale 1. Existing entities retained.")
              (prompt "\nReview the sheet, then use SAVEAS to create a new DWG. Original is not saved.")
              (prompt "\nUse UNDO once to remove this addition. Repeated DGREV is blocked by its marker.")))
          (vl-catch-all-apply 'vl-file-delete (list temporary))
        )
      )
    )
  )
  (princ)
)

(princ "\nDGREV loaded. Open the ORIGINAL drawing and enter DGREV.")
(princ)
